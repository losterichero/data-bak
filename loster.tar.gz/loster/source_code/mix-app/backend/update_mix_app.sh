#!/bin/bash

# 注意： 需要将此脚本放在与source_code目录同级目录下

set -e

# 获取当前文件所在的路径
CURRENT_DIR=$(pwd)

CONTAINER_NAME="mix_app"
BASE_IMAGE_NAME="mix-app"
TIMESTAMP=$(date +%Y%m%d)  # 获取到日的时间戳
NEW_IMAGE_NAME="${BASE_IMAGE_NAME}:1.0-${TIMESTAMP}"


echo "当前文件所在目录: $CURRENT_DIR"

echo "同步代码到容器中（排除日志文件）..."

# 将当前目录下的代码（排除 log/ 下日志）复制到容器中
docker cp "$CURRENT_DIR/source_code/mix-app/backend/" "$CONTAINER_NAME":/app_temp
docker exec "$CONTAINER_NAME" bash -c "rm -rf /app/* && cp -r /app_temp/* /app/ && rm -rf /app_temp"
docker exec "$CONTAINER_NAME" bash -c "find /app/log.txt /app/log /app/logs -type f -name '*.log' -delete || true"

echo "提交新的容器镜像..."
docker commit "$CONTAINER_NAME" "$NEW_IMAGE_NAME"

echo "停止并删除旧容器..."
docker stop "$CONTAINER_NAME"
docker rm "$CONTAINER_NAME"

echo "基于新镜像重新运行容器..."
docker compose up -d

echo "更新完成 🎉"
echo "新的镜像标签: $NEW_IMAGE_NAME"
