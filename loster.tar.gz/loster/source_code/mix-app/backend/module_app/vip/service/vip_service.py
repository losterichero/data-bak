from datetime import datetime, timedelta, time
import uuid
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, and_, or_, func
from typing import List, Dict, Optional
from module_admin.entity.do.user_do import SysUser
from utils.response_util import ResponseUtil
from module_admin.entity.vo.user_vo import CurrentUserModel
from utils.page_util import PageUtil
from module_app.vip.entity.do.vip_do import VipCard, UserCardMapping
from module_admin.entity.do.dept_do import SysDept
from utils.log_util import logger


class VipService:
    """
    会员卡密服务类
    """
    
    @staticmethod
    async def get_latest_batch_no(db: AsyncSession) -> str:
        """
        获取最新的批次号
        
        Args:
            db: 数据库会话
            
        Returns:
            str: 最新的批次号，如果没有记录则返回None
        """
        try:
            # 查询最大的批次号
            query = select(func.max(VipCard.batch_no))
            result = await db.execute(query)
            latest_batch = result.scalar()
            return latest_batch
        except Exception as e:
            logger.error(f"获取最新批次号失败: {str(e)}")
            return None
    
    @staticmethod
    async def generate_cards(
        db: AsyncSession,
        current_user: CurrentUserModel,
        deptId: str,
        count: int = 1,
        valid_days: int = 30,
        batch_no: str = "",
        remark: str = "",
    ) -> Dict:
        """
        生成卡密
        Args:
            db: 数据库会话
            current_user: 当前用户
            count: 生成数量
            valid_days: 有效天数
            batch_no: 批次号（可选，不传则自动递增）
            remark: 备注
        Returns:
            生成的卡密列表
        """
        try:
            # 如果没有提供批次号，则自动生成
            latest_batch = await VipService.get_latest_batch_no(db)
            batch_no = str(int(latest_batch) + 1) if latest_batch else "1"
            cards = []
            for _ in range(count):
                expire_time = datetime.now() + timedelta(days=valid_days)
                
                # 创建卡密对象
                db_card = VipCard(
                    id=str(uuid.uuid4()),
                    dept_id=str(deptId),
                    card_no=str(uuid.uuid4()).replace("-", ""),
                    valid_days=valid_days,
                    batch_no=batch_no,
                    expire_time=expire_time,
                    create_time=datetime.now(),
                    create_by=current_user.user.user_name,
                    remark=remark,
                    status="0"  # 未使用
                )
                db.add(db_card)
                cards.append(db_card)
            
            await db.flush()
            await db.commit()
            
            return ResponseUtil.success(msg=f"生成卡密成功,批次号:{batch_no},数量:{count}")
        except Exception as e:
            await db.rollback()
            logger.error(f"生成卡密失败: {str(e)}")
            return ResponseUtil.error(msg=f"生成卡密失败: {str(e)}")

    @staticmethod
    async def exchange_card(
        db: AsyncSession,
        current_user: CurrentUserModel,
        card_no: str
    ) -> Dict:
        """
        兑换卡密
        Args:
            db: 数据库会话
            current_user: 当前用户
            card_no: 卡号
        Returns:
            兑换结果
        """
        try:
            if not card_no:
                return ResponseUtil.error(msg="卡号不能为空")
                
            # 查询卡密信息
            query = (
                select(VipCard)
                .where(
                    VipCard.card_no == card_no,
                    VipCard.status == "0"
                )
            )
            result = await db.execute(query)
            card = result.scalar_one_or_none()
            
            if not card:
                return ResponseUtil.error(msg="卡密无效或已使用")
            
            # 计算过期时间（精确到日）
            now = datetime.now()
            expire_date = now.date() + timedelta(days=card.valid_days)
            expire_time = datetime.combine(expire_date, time(23, 59, 59))

            # 查询用户是否已有会员记录
            mapping_query = (
                select(UserCardMapping)
                .where(
                    UserCardMapping.user_id == str(current_user.user.user_id),
                )
            )
            mapping_result = await db.execute(mapping_query)
            existing_mapping = mapping_result.scalar_one_or_none()
            
            if existing_mapping:
                # 如果存在未过期的会员记录，则延长过期时间
                new_expire_date = existing_mapping.expire_date + timedelta(days=card.valid_days)
                update_mapping_query = (
                    update(UserCardMapping)
                    .where(UserCardMapping.id == existing_mapping.id)
                    .values(
                        expire_date=new_expire_date,
                        exchange_time=now
                    )
                )
                await db.execute(update_mapping_query)
                expire_date = new_expire_date
            else:
                # 创建新的用户卡密映射记录
                mapping = UserCardMapping(
                    id=str(uuid.uuid4()),
                    card_id=card.id,
                    user_id=str(current_user.user.user_id),
                    exchange_time=now,
                    expire_date=expire_date
                )
                db.add(mapping)
                
            # 更新卡密状态
            update_query = (
                update(VipCard)
                .where(VipCard.id == card.id)
                .values(
                    status="1",
                    user_id=str(current_user.user.user_id),
                    exchange_time=now,
                    update_by=str(current_user.user.user_id),
                    update_time=now,
                    expire_time=expire_time
                )
            )
            await db.execute(update_query)
            
            # 返回兑换结果
            return ResponseUtil.success(msg="兑换成功", data={
                "card_no": card.card_no,
                "valid_days": card.valid_days,
                "expire_date": expire_date.isoformat(),
                "exchange_time": now.isoformat(),
                "is_renewal": existing_mapping is not None
            })
            
        except Exception as e:
            logger.error(f"兑换卡密失败: {str(e)}")
            return ResponseUtil.error(msg=f"兑换失败: {str(e)}")

    @staticmethod
    async def get_card_list(
        db: AsyncSession,
        deptId: str,
        page_num: int = 1,
        page_size: int = 10,
        status: Optional[str] = None,
    ) -> Dict:
        """
        获取卡密列表
        Args:
            db: 数据库会话
            current_user: 当前用户
            page_num: 页码
            page_size: 每页数量
            status: 状态筛选
            batch_no: 批次号筛选
            begin_time: 开始时间
            end_time: 结束时间
        Returns:
            卡密列表
        """
        try:
            # 构建查询
            query = (
                select(
                    VipCard,
                    SysDept.dept_name
                )
                .outerjoin(
                    SysDept,
                    VipCard.dept_id == SysDept.dept_id
                )
                .where(
                    VipCard.dept_id == deptId,
                    VipCard.status == status if status else True
                )
                .order_by(VipCard.create_time.desc())
            )
            
            # 执行分页查询
            result = await PageUtil.paginate(db, query, page_num, page_size, True)
            
            # 处理结果
            if hasattr(result, 'rows'):
                result.rows = [
                    {**card, 'deptName': dept_name or '未知部门'}
                    for card, dept_name in result.rows
                ]
            
            return ResponseUtil.success(data=result)
        except Exception as e:
            logger.error(f"获取卡密列表失败: {str(e)}")
            return ResponseUtil.error(msg=f"获取卡密列表失败: {str(e)}")

    @staticmethod
    async def check_card_status(
        db: AsyncSession,
        card_no: str
    ) -> Dict:
        """
        检查卡密状态
        Args:
            db: 数据库会话
            card_no: 卡号
        Returns:
            卡密状态信息
        """
        try:
            query = (
                select(
                    VipCard,
                    SysDept.dept_name.label('dept_name')
                )
                .outerjoin(
                    SysDept,
                    VipCard.dept_id == SysDept.dept_id
                )
                .where(VipCard.card_no == card_no)
            )
            result = await db.execute(query)
            card = result.scalar_one_or_none()
            
            if not card:
                return ResponseUtil.error(msg="卡密不存在")
            
            # 添加部门名称
            if hasattr(card, 'dept_name'):
                card.dept_name = card.dept_name or '未知部门'
                
            return ResponseUtil.success(data={"card": card})
        except Exception as e:
            return ResponseUtil.error(msg=f"检查卡密状态失败: {str(e)}")

    @staticmethod
    async def batch_delete_cards(
        db: AsyncSession,
        card_ids: List[str]
    ) -> Dict:
        """
        批量删除卡密
        Args:
            db: 数据库会话
            card_ids: 卡密ID列表
        Returns:
            删除结果
        """
        try:
     
            delete_query = (
                VipCard.__table__.delete()
                .where(VipCard.id.in_(card_ids),VipCard.status != "1")
            )
            await db.execute(delete_query)
            await db.commit()
            # 返回删除结果
            return ResponseUtil.success(msg="删除成功")
        except Exception as e:
            await db.rollback()
            logger.error(f"批量删除卡密失败: {str(e)}")
            return ResponseUtil.error(msg=f"批量删除卡密失败: {str(e)}")

    @staticmethod
    async def get_user_cards(
        db: AsyncSession,
        user_id: str,
        page_num: int = 1,
        page_size: int = 10
    ) -> Dict:
        """
        获取用户的卡密列表
        Args:
            db: 数据库会话
            user_id: 用户ID
            page_num: 页码
            page_size: 每页数量
        Returns:
            用户的卡密列表
        """
        try:
            # 构建查询
            query = (
                select(
                    UserCardMapping,
                    VipCard.card_no,
                    VipCard.valid_days,
                    VipCard.batch_no,
                    VipCard.remark
                )
                .join(
                    VipCard,
                    UserCardMapping.card_id == VipCard.id
                )
                .where(
                    UserCardMapping.user_id == user_id
                )
                .order_by(UserCardMapping.exchange_time.desc())
            )
            
            # 执行分页查询
            result = await PageUtil.paginate(db, query, page_num, page_size, True)
            
            # 处理结果
            if hasattr(result, 'rows'):
                result.rows = [
                    {
                        "id": mapping.id,
                        "card_no": card_no,
                        "valid_days": valid_days,
                        "batch_no": batch_no,
                        "remark": remark,
                        "exchange_time": mapping.exchange_time,
                        "expire_date": mapping.expire_date
                    }
                    for mapping, card_no, valid_days, batch_no, remark in result.rows
                ]
            
            return ResponseUtil.success(data=result)
        except Exception as e:
            logger.error(f"获取用户卡密列表失败: {str(e)}")
            return ResponseUtil.error(msg=f"获取用户卡密列表失败: {str(e)}")


    @staticmethod
    async def get_vip_card_info(db: AsyncSession,user_id: str) -> Dict:
        try:
            query = (
                select(UserCardMapping, SysUser.email,SysUser.nick_name)
                .join(SysUser, UserCardMapping.user_id == SysUser.user_id)
                .where(UserCardMapping.user_id == user_id)
            )
            result = await db.execute(query)
            row = result.first()
            if not row:
                return ResponseUtil.success(data=None)
            print('查询出来的信息',row)
            mapping, user_name, nick_name = row
            return ResponseUtil.success(data={**mapping.__dict__, "user_name": user_name,"nick_name":nick_name})
        except Exception as e:
            logger.error(f"获取VIP信息失败: {str(e)}")
            return ResponseUtil.error(msg=f"获取VIP信息失败: {str(e)}")
