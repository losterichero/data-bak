from fastapi import APIRouter, Depends, Request
from module_admin.service.login_service import LoginService
from module_admin.entity.vo.user_vo import CurrentUserModel
from utils.response_util import ResponseUtil
from sqlalchemy.ext.asyncio import AsyncSession
from config.get_db import get_db
from module_admin.annotation.log_annotation import Log
from config.enums import BusinessType
from module_app.vip.service.vip_service import VipService
from utils.log_util import logger

vipController = APIRouter(prefix='/vip')

@vipController.post("/generate-cards")
@Log(title="生成卡密", business_type=BusinessType.INSERT)
async def generate_cards_api(
    request: Request,
    data: dict,
    current_user: CurrentUserModel = Depends(LoginService.get_current_user),
    query_db: AsyncSession = Depends(get_db)
):
    """
    生成卡密
    Args:
        data: {
            "count": 生成数量,
            "valid_days": 有效天数,
            "batch_no": 批次号（可选，不传则自动递增）,
            "remark": 备注
        }
    """
    count = data.get("count", 1)
    valid_days = data.get("valid_days", 30)
    batch_no = data.get("batch_no")
    remark = data.get("remark", "")
    deptId = data.get("deptId", "")
    
    # 如果没有提供批次号，则自动生成
    if not batch_no:
        # 查询最新的批次号
        latest_batch = await VipService.get_latest_batch_no(query_db)
        batch_no = str(int(latest_batch) + 1) if latest_batch else "1"
    
    return await VipService.generate_cards(
        db=query_db,
        current_user=current_user,
        count=count,
        valid_days=valid_days,
        batch_no=batch_no,
        remark=remark,
        deptId=deptId
    )

@vipController.post("/exchange-card")
@Log(title='兑换卡密', business_type=BusinessType.INSERT, log_type='exchange_card')
async def exchange_card_api(
    request: Request,
    data: dict,
    current_user: CurrentUserModel = Depends(LoginService.get_current_user),
    query_db: AsyncSession = Depends(get_db)
):
    """
    兑换卡密
    Args:
        data: {
            "card_no": 卡号
        }
    """
    card_no = data.get("cardNumber")
    return await VipService.exchange_card(
        db=query_db,
        current_user=current_user,
        card_no=card_no
    )

@vipController.get("/card-list")
async def get_card_list_api(
    query_db: AsyncSession = Depends(get_db),
    page_num: int = 1,
    page_size: int = 10,
    status: str = None,
    deptId: str = None,
):
    """
    获取卡密列表
    Args:
        page_num: 页码
        page_size: 每页数量
        status: 状态筛选
        batch_no: 批次号筛选
        begin_time: 开始时间
        end_time: 结束时间
    """
    return await VipService.get_card_list(
        db=query_db,
        deptId=deptId,
        page_num=page_num,
        page_size=page_size,
        status=status,
    )

@vipController.delete("/batch-delete-cards")
@Log(title="批量删除卡密", business_type=BusinessType.DELETE)
async def batch_delete_cards_api(
    data: dict,
    query_db: AsyncSession = Depends(get_db)
):
    """
    批量删除卡密
   
    """
    card_ids = data.get("cardIds", [])
    return await VipService.batch_delete_cards(
        db=query_db,
        card_ids=card_ids
    )

@vipController.get("/vip-card-info")
async def get_vip_card_info_api(
    query_db: AsyncSession = Depends(get_db),
    current_user: CurrentUserModel = Depends(LoginService.get_current_user)
):
    return await VipService.get_vip_card_info(
        db=query_db,
        user_id=current_user.user.user_id
    )

