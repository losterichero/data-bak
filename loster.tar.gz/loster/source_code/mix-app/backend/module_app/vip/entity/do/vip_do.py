from datetime import datetime
from sqlalchemy import Column, DateTime, Integer, String, Date, ForeignKey
from sqlalchemy.orm import relationship
from config.database import Base


class VipCard(Base):
    """
    会员卡密表
    """
    __tablename__ = 'vip_card'

    id = Column(String(255), primary_key=True, comment='主键ID')
    dept_id = Column(String(255), nullable=False, comment='部门ID')
    card_no = Column(String(255), nullable=False, unique=True, comment='卡号')
    valid_days = Column(Integer, nullable=False, comment='有效天数')
    batch_no = Column(String(255), nullable=False, comment='批次号')
    expire_time = Column(DateTime, nullable=False, comment='过期时间')
    create_time = Column(DateTime, nullable=False, comment='创建时间')
    create_by = Column(String(255), nullable=False, comment='创建人')
    update_time = Column(DateTime, comment='更新时间')
    update_by = Column(String(255), comment='更新人')
    status = Column(String(1), nullable=False, default='0', comment='状态（0未使用 1已使用）')
    user_id = Column(String(255), comment='用户ID')
    exchange_time = Column(DateTime, comment='兑换时间')
    remark = Column(String(500), comment='备注')


class UserCardMapping(Base):
    """
    用户与卡密兑换记录映射表
    """
    __tablename__ = 'user_card_mapping'
    
    id = Column(String(255), primary_key=True, comment='主键ID')
    card_id = Column(String(255), nullable=False, comment='卡密ID，关联vip_card表')
    user_id = Column(String(255), nullable=False, comment='用户ID，关联用户表')
    exchange_time = Column(DateTime, nullable=False, server_default='CURRENT_TIMESTAMP', comment='兑换时间')
    expire_date = Column(Date, nullable=False, comment='过期日期')
