from operator import index

from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes, MessageHandler, filters

from config.es_clinet import ElasticsearchClient

# 替换成你自己的 Token
TOKEN = "7943680714:AAFtK1O1iEWJZL1thcbiumtQCNj9g7dhySo"
# 创建 Elasticsearch 客户端实例
es_client = ElasticsearchClient()
# 处理 /start 命令
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("你好，我是glen quagmire！may i help you!x")

# 处理 /start 命令
async def test(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("测试消息")

async def search(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """搜索 Telegram 消息"""

    user_text = update.message.text
    print(f'用户消息:{user_text}')
    # 构造查询体
    # 构造查询体
    search_body = {
        "query": {
            "bool": {
                "should": [
                    {
                        "match": {
                            "message_text": user_text  # 在消息字段中查找关键词
                        }
                    },
                    {
                        "match": {
                            "sender": user_text  # 匹配发件人
                        }
                    }
                ],
                "minimum_should_match": 1  # 至少满足一个条件
            }
        },
    }

    index = "telegram_messages"
    # 执行搜索请求
    try:
        response = es_client.search(index=index, body=search_body,size=100)
        print(f"完整响应：{response}")  # 打印响应查看数据结构
        hits = response.get("hits", {}).get("hits", [])

        # 返回结果
        results = [{"id": hit["_id"], "message_text": hit["_source"]["message_text"],
                    "sender": hit["_source"]["sender"]
                    } for hit in hits]

        await update.message.reply_text(f"/{user_text}：{results}")

    except Exception as e:
        print(f"错误信息: {e}")
        await update.message.reply_text(f"/发生错误：{e}")


# 创建机器人应用
app = ApplicationBuilder().token(TOKEN).build()
# 添加命令处理器和消息处理器
app.add_handler(CommandHandler("start", start))
app.add_handler(MessageHandler(filters.TEXT & (~filters.COMMAND), search))  # 忽略命令，仅处理普通文本
app.add_handler(CommandHandler("test", test))

# 启动机器人
if __name__ == "__main__":
    print("机器人已启动...")
    app.run_polling()
