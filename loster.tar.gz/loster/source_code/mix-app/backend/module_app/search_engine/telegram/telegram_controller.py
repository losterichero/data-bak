from elasticsearch.helpers import bulk
from fastapi import Depends, APIRouter, Query, HTTPException
from config.es_clinet import ElasticsearchClient
from utils import redis_client
from utils.response_util import ResponseUtil

# telegramController = APIRouter(prefix='/system/config', dependencies=[Depends(LoginService.get_current_user)])



# @telegramController.get(
#     '/list', response_model=PageResponseModel, dependencies=[Depends(CheckUserInterfaceAuth('system:config:list'))]
# )
telegramController = APIRouter(prefix='/telegram')


# 创建 Elasticsearch 客户端实例
# es_client = ElasticsearchClient()
es_client = None


@telegramController.get("/search")
async def search_telegram_messages(
        query: str = Query(..., description="搜索关键字"),
        index: str = Query("telegram_messages", description="Elasticsearch 索引名称"),
        size: int = Query(10, description="每页返回的结果数量"),
        page: int = Query(1, description="页码，默认为 1")
):
    """搜索 Telegram 消息"""

    # 计算分页的 from 值
    from_value = (page - 1) * size

    # 构造查询体
    # 构造查询体
    search_body = {
        "query": {
            "bool": {
                "should": [
                    {
                        "match": {
                            "message_text": query  # 在消息字段中查找关键词
                        }
                    },
                    {
                        "match": {
                            "sender": query  # 匹配发件人
                        }
                    }
                ],
                "minimum_should_match": 1  # 至少满足一个条件
            }
        },
    }

    # 执行搜索请求
    try:
        response = es_client.search(index=index, body=search_body,size=size)
        print(f"完整响应：{response}")  # 打印响应查看数据结构
        hits = response.get("hits", {}).get("hits", [])

        # 返回结果
        results = [{"id": hit["_id"], "message_text": hit["_source"]["message_text"],
                    "sender": hit["_source"]["sender"]
                    } for hit in hits]

        if not results:
            raise HTTPException(status_code=404, detail="No messages found")

        return {"results": results, "page": page, "size": size}

    except Exception as e:
        print(f"错误信息: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@telegramController.get("/search-all")
async def search_all_telegram_messages(
        index: str = Query("telegram_messages", description="Elasticsearch 索引名称"),
        size: int = Query(1000, description="返回的结果数量，默认 1000")
):
    """查询所有 Telegram 消息"""

    # 构造查询体
    search_body = {
        "query": {
            "match_all": {}  # 使用 match_all 查询所有数据
        },
        "size": size  # 返回最多 size 条记录
    }

    # 执行搜索请求
    try:
        response = es_client.search(index=index, body=search_body)
        print(f"完整响应：{response}")  # 打印响应查看数据结构
        hits = response.get("hits", {}).get("hits", [])

        # 返回结果
        results = [{"id": hit["_id"], "message_text": hit["_source"]["message_text"]} for hit in hits]

        if not results:
            raise HTTPException(status_code=404, detail="No messages found")

        return {"results": results}

    except Exception as e:
        print(f"错误信息: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# 批量导入数据到 Elasticsearch
@telegramController.get("/insert")
async def index_bulk_data():
    messages = [
        {"message_text": "昨晚的比赛真是太激动人心了！", "sender": "李伟", "timestamp": "2025-04-08T08:00:00",
         "chat_id": 3485},
        {"message_text": "今天晚上我们去吃火锅怎么样？", "sender": "王娜", "timestamp": "2025-04-08T08:01:10",
         "chat_id": 2097},
        {"message_text": "这个项目进展如何了？需要我帮忙吗？", "sender": "张明", "timestamp": "2025-04-08T08:02:25",
         "chat_id": 4105},
        {"message_text": "别忘了明天早上八点的会议哦。", "sender": "赵亮", "timestamp": "2025-04-08T08:03:40",
         "chat_id": 5402},
        {"message_text": "我感觉最近有点累，可能需要休息一下。", "sender": "刘洋", "timestamp": "2025-04-08T08:04:55",
         "chat_id": 3214},
        {"message_text": "你能帮我查一下这个文件吗？", "sender": "陈静", "timestamp": "2025-04-08T08:06:10",
         "chat_id": 1279},
        {"message_text": "快点过来，别让我等太久。", "sender": "黄浩", "timestamp": "2025-04-08T08:07:20",
         "chat_id": 6451},
        {"message_text": "昨天买的手机真不错，推荐你也试试。", "sender": "孙婷", "timestamp": "2025-04-08T08:08:35",
         "chat_id": 7326},
        {"message_text": "你知道今天的新闻吗？好像有大新闻。", "sender": "郭峰", "timestamp": "2025-04-08T08:09:45",
         "chat_id": 5072},
        {"message_text": "这周末要不要一起去爬山？", "sender": "徐华", "timestamp": "2025-04-08T08:10:55",
         "chat_id": 3348},
        {"message_text": "最近发现一本书，内容挺有意思的，你看过吗？", "sender": "冯敏",
         "timestamp": "2025-04-08T08:12:05", "chat_id": 5218},
        {"message_text": "这个周的工作安排你看一下，反馈给我。", "sender": "杨磊", "timestamp": "2025-04-08T08:13:15",
         "chat_id": 4869},
        {"message_text": "今天晚上的电影你想看什么？", "sender": "张萍", "timestamp": "2025-04-08T08:14:25",
         "chat_id": 3881},
        {"message_text": "突然想到一个创意，等会儿给你打电话。", "sender": "李婷", "timestamp": "2025-04-08T08:15:35",
         "chat_id": 5993},
        {"message_text": "周末去海边怎么样？我已经计划好了。", "sender": "陈鹏", "timestamp": "2025-04-08T08:16:45",
         "chat_id": 2412},
        {"message_text": "收到快递了，应该是我订的那个东西。", "sender": "吴丽", "timestamp": "2025-04-08T08:17:55",
         "chat_id": 3507},
        {"message_text": "我最近有点感冒，可能要休息几天。", "sender": "赵珊", "timestamp": "2025-04-08T08:19:05",
         "chat_id": 5423},
        {"message_text": "我还没做完作业，今晚要加班了。", "sender": "高峰", "timestamp": "2025-04-08T08:20:15",
         "chat_id": 4136}
    ]

    actions = []
    for message in messages:
        action = {
            "_op_type": "index",
            "_index": "telegram_messages",
            "_source": message
        }
        actions.append(action)
    success, failed = bulk(es_client.client, actions)
    return ResponseUtil.success(msg="插入成功")


# 批量导入数据到 Elasticsearch
@telegramController.get("/test")
async def index_bulk_data():

    return ResponseUtil.success(msg="hello telegram")