from fastapi import APIRouter, Query
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes


telegramController = APIRouter(prefix='/telegram-bot')

TOKEN = "7943680714:AAFtK1O1iEWJZL1thcbiumtQCNj9g7dhySo"

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("你好，我是一个机器人！")

# 创建机器人应用
app = ApplicationBuilder().token(TOKEN).build()
app.add_handler(CommandHandler("start", start))

# 启动机器人
app.run_polling()

@telegramController.get("/test")
async def search_telegram_messages(
        message: str = Query(..., description="搜索关键字"),
):
    """

    """