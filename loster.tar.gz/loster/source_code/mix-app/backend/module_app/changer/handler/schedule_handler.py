import json
import math
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from datetime import datetime, timedelta
from apscheduler.jobstores.redis import RedisJobStore
from config.env import RedisConfig
from module_app.changer.handler.step_change_core import modify_step
from utils.redis_client import get_redis as get_redis_client
from utils.response_util import ResponseUtil

# 配置 RedisJobStore(任务持久化配置)
job_stores = {
    'default': RedisJobStore(
        host=RedisConfig.redis_host,
        port=RedisConfig.redis_port,
        db=RedisConfig.redis_database,
        jobs_key='wechat_jobs',  # 存储任务的键
        run_times_key='wechat_jobs_run_times',  # 存储运行时间的键
    )
}

# 配置调度器
scheduler = AsyncIOScheduler(jobstores=job_stores)

# 获取用户任务配置
async def get_user_task_config(user_id):
    redis = get_redis_client()
    user_tasks = await redis.get(f'user_task:{user_id}')
    if user_tasks:
        user_tasks = json.loads(user_tasks)
    else:
        user_tasks = None
    return user_tasks

# 存储用户任务配置
async def set_user_task(user_id, config):
    if config:
        redis = get_redis_client()
        await redis.set(f'user_task:{user_id}', json.dumps(config))


async def delete_task(user_id: str):
    """
    删除用户任务
    Args:
        user_id: 用户ID
    Returns:
        bool: 删除是否成功
    """
    try:
        # 删除Redis中的任务配置
        redis = get_redis_client()
        await redis.delete(f'user_task:{user_id}')
        
        # 检查并删除调度器中的任务
        job = scheduler.get_job(str(user_id))
        if job:
            scheduler.remove_job(str(user_id))
            print(f"已删除用户 {user_id} 的调度任务")
        
        return True
    except Exception as e:
        print(f"删除任务时出错: {str(e)}")
        return False
    
async def get_task_today_all_run_times(user_id: str):
    """
    获取用户任务当天所有理论执行时间点（包括已过去的）
    :param user_id: 用户ID
    :return: 当天所有执行时间列表
    """
    job = scheduler.get_job(str(user_id))
    if not job or not job.next_run_time:
        return []

    tzinfo = job.next_run_time.tzinfo
    today = datetime.now(tz=tzinfo).replace(hour=0, minute=0, second=0, microsecond=0)
    tomorrow = today + timedelta(days=1)
    run_times = []

    # 获取当天0点的第一个触发点
    next_run = job.trigger.get_next_fire_time(None, today)
    while next_run and next_run < tomorrow:
        run_times.append(next_run.strftime('%Y-%m-%d %H:%M:%S'))
        next_run = job.trigger.get_next_fire_time(next_run, next_run)

    return run_times

async def generate_today_task_list(user_id: str, target_step: int):
    """
    根据当天所有执行时间点和目标步数，生成步数执行列表
    :param user_id: 用户ID
    :param target_step: 目标步数
    :return: 步数执行列表
    """
    run_times = await get_task_today_all_run_times(user_id)
    if not run_times:
        return []

    time_list = [t[-8:-3] for t in run_times]  # 'YYYY-MM-DD HH:MM:SS' -> 'HH:MM'
    step_per_time = target_step / len(time_list)
    task_list = []
    for i, time in enumerate(time_list):
        if i == len(time_list) - 1:
            step = target_step
        else:
            step = int(step_per_time * (i + 1))
        task_list.append({
            "step": step,
            "time": time
        })
    return task_list    

async def wechat_step_change_task(user_id):  
    try:
        config = await get_user_task_config(user_id)
        if config:
            user = config['account_config']['zf_account']
            password = config['account_config']['password']
            target_step = config['time_config']['target_step']

            # 使用 generate_today_task_list 获取步数执行列表
            task_list = await generate_today_task_list(user_id, target_step)
            # 当前时间
            current_time = datetime.now().strftime("%H:%M")

            # 查找当前时间对应的步数
            for task in task_list:
                if task['time'] == current_time:
                    current_step = task['step']
                    # 修改步数
                    await modify_step(user=user, password=password, step=current_step)
                    # 更新当前步数
                    config['cur_step'] = current_step
                    await set_user_task(user_id, config)
                    break
    except Exception as e:
        print(f"异步任务执行出错: {str(e)}")
        raise e



async def create_task(config: dict):
    user_id = config.get('user_id')
    await delete_task(user_id)
    
    # 生成步数时间列表
    start_time = config.get('time_config').get('start_time')
    end_time = config.get('time_config').get('end_time')
    target_step = config.get('time_config').get('target_step')
    mode = config.get('time_config').get('mode')
    
    if target_step <= 0:
        return False
    config['cur_step'] = 0
    
    # 存储配置到Redis
    redis = get_redis_client()
    await redis.set(f'user_task:{user_id}', json.dumps(config))
    
    # 创建一个新的定时任务
    minute = '0'
    if mode == 0.5:
        minute = '0,30'  # 在每小时的第0,30 分钟执行
    scheduler.add_job(
        wechat_step_change_task,  # 直接使用异步函数
        CronTrigger(
            minute=minute,  
            hour=f"{int(start_time.split(':')[0])}-{int(end_time.split(':')[0])}",   
            day_of_week='*',  # 每天
            month='*'  # 每个月
        ),
        args=[user_id],
        id=str(user_id)  # 使用用户ID作为任务ID
    )
    print(f'当天所有执行时间--->{await get_task_today_all_run_times(str(user_id))}')
    return True

# 启动调度器的函数
async def start_scheduler():
    if not scheduler.running:
        scheduler.start()

async def get_task_info(user_id):
    """
    获取任务信息
    Args:
        user_id: 用户ID
        count: 获取的执行次数，默认为5次
    Returns:
        包含任务配置、状态和执行时间步数列表的响应
    """
    task_config = await get_user_task_config(user_id)
    if not task_config:
        return ResponseUtil.success(msg="未找到任务配置")
    
    # 获取任务状态
    job = scheduler.get_job(str(user_id))
    task_status = "running" if job else "stopped"
    target_step = task_config.get('time_config').get('target_step') 
    
    # 从配置中获取任务列表
    task_list = await generate_today_task_list(user_id, target_step)
        
    # 移除敏感信息
    task_config.pop('account_config')
    
    # 构建返回数据
    response_data = {
        "task_config": task_config,
        "task_status": task_status,
        "task_list": task_list
    }
    
    return ResponseUtil.success(data=response_data)






