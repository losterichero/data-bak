import json
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from module_app.changer.handler.schedule_handler import create_task, delete_task
from module_app.changer.handler.step_change_core import modify_step, get_app_token
from utils.response_util import ResponseUtil
from module_admin.entity.do.user_do import SysUser




async def wechat_step_change(user_info, step: int, query_db: AsyncSession):
    """
    微信步数修改
    """
    user_id = user_info.get('userId')
    result = await query_db.execute(select(SysUser).where(SysUser.user_id == user_id))
    user = result.scalar_one_or_none()
    res = await modify_step(user.email, user.password, step)
    if res.get('success'):
        return ResponseUtil.success(msg="微信步数修改成功")
    else:
        return ResponseUtil.error(msg=res.get('msg'))


def check_account(username: str, password: str) -> bool:
    """
    检查账号是否可用
    """
    res = get_app_token(user=username, password=password)
    if "app_token" in res.get('msg'):
        return True
    else:
        return False

async def update_config(user_info, config, query_db: AsyncSession):
    """
    配置修改
    """
    user_id = user_info.get('userId')
    stmt = select(SysUser).where(SysUser.user_id == user_id)
    result = await query_db.execute(stmt)
    user = result.scalar_one_or_none()
    if user.get('user_basic_info'):
        # 可修改配置列表
        params = ['zf_account', 'password']
        real_config = {}
        for key in config.keys():
            if key in params:
                real_config[key] = config[key]
        user.get('user_basic_info').account_config = json.dumps(real_config)
        await query_db.commit()
        await query_db.refresh(user.get('user_basic_info'))
        return ResponseUtil.success(msg="配置修改成功")
    else:
        return ResponseUtil.error(msg="配置修改失败")

async def create_wechat_task(user_id, config, query_db: AsyncSession):
    """
    创建定时任务
    """
    result = await query_db.execute(select(SysUser).where(SysUser.user_id == user_id))
    user = result.scalar_one_or_none()
    data = {'user_id': user_id,
            'account_config': {'zf_account': user.email,
                               'password': user.password},
            'time_config': {
                'start_time': config.get('start_time'),  # 开始时间
                'end_time': config.get('end_time'),  # 结束时间
                'target_step': config.get('target_step'),  # 步数
                'mode': config.get('mode'),  # 次数
                'deadline': ""  # 截止日期
            }
            }
    res = await create_task(config=data)
    if res:
        return ResponseUtil.success(msg="开始定时任务")
    else:
        return ResponseUtil.error(msg="创建定时任务失败")

async def delete_wechat_task(user_id):
    """
    删除定时任务
    """
    res = await delete_task(user_id)
    if res:
        return ResponseUtil.success(msg="停止定时任务")
    else:
        return ResponseUtil.error(msg="停止定时任务失败")