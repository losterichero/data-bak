from datetime import datetime
from utils.response_util import ResponseUtil
from utils.pwd_util import PwdUtil
from exceptions.exception import ServiceException
from module_admin.entity.do.user_do import SysUser
from module_admin.entity.do.dept_do import SysDept
from module_app.changer.entity.UserExtendInfo import UserExtendInfo
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from fastapi import Request
from module_admin.entity.vo.user_vo import CurrentUserModel
from module_admin.service.login_service import LoginService
from datetime import timedelta
import uuid
from module_app.changer.handler.step_change_handler import check_account

from config.env import AppConfig, JwtConfig
from module_admin.annotation.log_annotation import Log
from config.enums import BusinessType, RedisInitKeyConfig
from config.env import ChangerConfig

async def register_user(user_data: dict, query_db: AsyncSession):
    """
    用户注册
    
    :param user_data: 用户信息字典
    :param query_db: 数据库会话
    :return: 注册结果
    """
    nick_name=user_data.get('nickName',None)
    email=user_data.get('email',None)
    password=user_data.get('password',None)
    
    # 检查必要参数
    if not all([nick_name, email, password]):
        return ResponseUtil.error(msg="缺少必要参数")
        
    try:
        # 检查邮箱是否已存在
        stmt = select(SysUser).where(SysUser.email == email)
        result = await query_db.execute(stmt)
        if result.scalar_one_or_none():
            return ResponseUtil.error(msg="邮箱已存在")
        
        is_valid = check_account(email, password)
        if not is_valid:
            return ResponseUtil.error(msg="账号无效")

        # 查询部门
        result = await query_db.execute(select(SysDept).where(SysDept.dept_name == ChangerConfig.user_dept))
        dept = result.scalar_one_or_none()
        if not dept:
            return ResponseUtil.error(msg="部门不存在")

        # 创建用户
        new_user = SysUser(
            user_name=email,
            nick_name=nick_name,
            password=password,
            email=email,
            create_time=datetime.now(),
            update_time=datetime.now(),
            dept_id=dept.dept_id
        )
        
        # 保存用户
        query_db.add(new_user)
        await query_db.flush()  # 获取新用户的ID
        
        # 创建用户扩展信息
        user_extend = UserExtendInfo(
            user_id=str(new_user.user_id),
            update_time=datetime.now(),
            app=user_data.get('app')
        )
        query_db.add(user_extend)
        
        # 提交事务
        await query_db.commit()
        return ResponseUtil.success(msg="注册成功")
        
    except Exception as e:
        await query_db.rollback()
        return ResponseUtil.error(msg=f"注册失败: {str(e)}")

@Log(title='用户登录', business_type=BusinessType.OTHER, log_type='login')
async def login(request: Request, data: dict, query_db: AsyncSession, form_data=None, login_info=None):
    """
    邮箱密码登录
    
    :param request: 请求对象
    :param data: 登录信息字典
    :param query_db: 数据库会话
    :param form_data: 表单数据
    :param login_info: 登录信息（由装饰器注入）
    :return: 登录结果
    """
    email = data.get('email')
    password = data.get('password')
    
    if not all([email, password]):
        return ResponseUtil.error(msg="缺少必要参数")
        
    try:
        # 查询用户
        result = await query_db.execute(select(SysUser).where(SysUser.email == email))
        user = result.scalar_one_or_none()
        # 查询部门
        result = await query_db.execute(select(SysDept).where(SysDept.dept_id == user.dept_id))
        dept = result.scalar_one_or_none()
        
        if not user or not (password == user.password):
            return ResponseUtil.error(msg="账号或密码错误")
            
        # 生成token
        session_id = str(uuid.uuid4())
        token_data = {
            'user_id': str(user.user_id),
            'user_name': user.user_name,
            'dept_name': dept.dept_name,
            'session_id': session_id,
            'login_info': login_info  # 直接使用装饰器注入的登录信息
        }
        access_token = await LoginService.create_access_token(
            request=request,
            data=token_data,
            expires_delta=timedelta(days=30)  # token有效期7天
        )
        if AppConfig.app_same_time_login:
            await request.app.state.redis.set(
                f'{RedisInitKeyConfig.ACCESS_TOKEN.key}:{session_id}',
                access_token,
                ex=timedelta(minutes=JwtConfig.jwt_redis_expire_minutes),
            )
        else:
            # 此方法可实现同一账号同一时间只能登录一次
            await request.app.state.redis.set(
                f'{RedisInitKeyConfig.ACCESS_TOKEN.key}:{result[0].user_id}',
                access_token,
                ex=timedelta(minutes=JwtConfig.jwt_redis_expire_minutes),
            )
        
        return ResponseUtil.success(data={
            "token": access_token,
            "user": {
                "user_id": user.user_id,
                "user_name": user.user_name,
                "nick_name": user.nick_name,
                "email": user.email
            }
        })
        
    except Exception as e:
        return ResponseUtil.error(msg=f"登录失败: {str(e)}")

async def get_user_info(user_id: int, query_db: AsyncSession):
    """
    获取用户详情
    
    :param user_id: 用户ID
    :param query_db: 数据库会话
    :return: 用户详情
    """
    try:
        # 查询用户基本信息
        stmt = select(SysUser).where(SysUser.user_id == user_id)
        result = await query_db.execute(stmt)
        user = result.scalar_one_or_none()
        
        if not user:
            return ResponseUtil.error(msg="用户不存在")
            
        # 查询用户扩展信息
        stmt = select(UserExtendInfo).where(UserExtendInfo.user_id == str(user_id))
        result = await query_db.execute(stmt)
        user_extend = result.scalar_one_or_none()
        
        # 构建返回数据
        user_info = {
            "user_id": user.user_id,
            "user_name": user.user_name,
            "nick_name": user.nick_name,
            "email": user.email,
            "create_time": user.create_time,
            "update_time": user.update_time,
            "app": user_extend.app if user_extend else None
        }
        
        return ResponseUtil.success(data=user_info)
        
    except Exception as e:
        return ResponseUtil.error(msg=f"获取用户信息失败: {str(e)}")
