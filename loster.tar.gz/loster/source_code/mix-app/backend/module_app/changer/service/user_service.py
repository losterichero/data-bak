from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from config.env import ChangerConfig
from module_admin.dao.notice_dao import NoticeDao
from module_admin.entity.do.dept_do import SysDept
from module_admin.entity.vo.notice_vo import NoticePageQueryModel
from utils.response_util import ResponseUtil
from module_admin.entity.do.user_do import SysUser
from module_app.changer.entity.UserExtendInfo import UserExtendInfo

class UserService:
    """
    用户服务类
    """
    
    @staticmethod
    async def get_user_info(user_id: int, query_db: AsyncSession):
        """
        获取用户详情
        
        :param user_id: 用户ID
        :param query_db: 数据库会话
        :return: 用户详情
        """
        try:
            # 查询用户基本信息
            stmt = select(SysUser).where(SysUser.user_id == user_id)
            result = await query_db.execute(stmt)
            user = result.scalar_one_or_none()
            
            if not user:
                return ResponseUtil.error(msg="用户不存在")
                
            # 查询用户扩展信息
            stmt = select(UserExtendInfo).where(UserExtendInfo.user_id == str(user_id))
            result = await query_db.execute(stmt)
            user_extend = result.scalar_one_or_none()
            
            # 构建返回数据
            user_info = {
                "user_id": user.user_id,
                "user_name": user.user_name,
                "nick_name": user.nick_name,
                "email": user.email,
                "create_time": user.create_time,
                "update_time": user.update_time,
                "app": user_extend.app if user_extend else None
            }
            
            return ResponseUtil.success(data=user_info)
            
        except Exception as e:
            return ResponseUtil.error(msg=f"获取用户信息失败: {str(e)}")

    @staticmethod
    async def update_user_info(user_id: int, data: dict, query_db: AsyncSession):
        """
        更新用户详情
        
        :param user_id: 用户ID
        :param data: 更新数据
        :param query_db: 数据库会话
        :return: 更新结果
        """
        try:
            nick_name = data.get("nick_name")
            if len(nick_name) > 12:
                return ResponseUtil.error(msg="昵称长度不能超过12个字符")
            # 查询用户基本信息
            stmt = select(SysUser).where(SysUser.user_id == user_id)
            result = await query_db.execute(stmt)
            user = result.scalar_one_or_none()
            if not user:
                return ResponseUtil.error(msg="用户不存在") 
            # 更新用户基本信息
            user.nick_name = nick_name
            await query_db.commit()
            return ResponseUtil.success(msg="用户信息更新成功")
        except Exception as e:
            return ResponseUtil.error(msg=f"更新用户信息失败: {str(e)}")


    @staticmethod
    async def get_changer_notices_api(query_db: AsyncSession):
  
        result = await query_db.execute(select(SysDept).where(SysDept.dept_name == ChangerConfig.user_dept))
        dept = result.scalar_one_or_none()
        if not dept:
            return ResponseUtil.error(msg="部门不存在")
        dept_id = dept.dept_id
        query_object = {
            'deptId': int(dept_id),
            'pageNum': 1,
            'pageSize': 100
        }
        notice_page_query = NoticePageQueryModel(**query_object)
        res_data = await  NoticeDao.get_notice_list(query_db,notice_page_query,is_page=True)
        return ResponseUtil.success(model_content=res_data)

