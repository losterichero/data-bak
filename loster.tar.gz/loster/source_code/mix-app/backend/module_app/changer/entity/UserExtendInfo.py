from datetime import datetime
from sqlalchemy import Column, String, DateTime
from config.database import Base

class UserExtendInfo(Base):
    """
    用户扩展信息表
    """
    
    __tablename__ = 'user_extend_info'
    
    user_id = Column(String(64), primary_key=True, comment='用户ID')
    account_config = Column(String(500), nullable=True, default=None, comment='账号配置')
    ip = Column(String(128), nullable=True, default=None, comment='IP地址')
    app = Column(String(64), nullable=True, default=None, comment='应用标识')
    update_time = Column(DateTime, nullable=True, default=datetime.now(), comment='更新时间')