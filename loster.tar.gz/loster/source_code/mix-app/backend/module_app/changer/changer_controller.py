from fastapi import APIRouter, Depends, Request
from module_admin.entity.vo.notice_vo import NoticePageQueryModel
from module_admin.service.login_service import LoginService
from module_admin.entity.vo.user_vo import CurrentUserModel
from module_app.changer.handler.step_change_handler import wechat_step_change,create_wechat_task,delete_wechat_task
from module_app.changer.service.auth_service import register_user, login
from module_app.changer.service.user_service import UserService
from utils.response_util import ResponseUtil
from sqlalchemy.ext.asyncio import AsyncSession
from config.get_db import get_db
from module_app.changer.handler.schedule_handler import get_task_info
from module_admin.dao.notice_dao import NoticeDao
from module_admin.annotation.log_annotation import Log
from config.enums import BusinessType

changerController = APIRouter(prefix='/changer')

@changerController.post("/wechat")
@Log(title='微信步数修改(手动)', business_type=BusinessType.OTHER, log_type='change-wechat-step')
async def wechat_step_change_api(
    request: Request,
    data: dict,
    current_user: CurrentUserModel = Depends(LoginService.get_current_user),
    query_db: AsyncSession = Depends(get_db)
):
    """
    修改微信步数
    """
    step = data.get("step")
    user_info = {"userId": current_user.user.user_id}
    return await wechat_step_change(user_info=user_info, step=step, query_db=query_db)

@changerController.post("/create-wechat-task")
async def create_task_api(
    data: dict,
    current_user: CurrentUserModel = Depends(LoginService.get_current_user),
    query_db: AsyncSession = Depends(get_db)
):
    """
    创建定时任务
    """
    print(f'创建定时任务---->{data}')
    return await create_wechat_task(current_user.user.user_id, data, query_db)

@changerController.delete("/delete-wechat-task")
async def delete_task_api(
    current_user: CurrentUserModel = Depends(LoginService.get_current_user),
):
    """
    删除定时任务(停止定时任务)
    """
    return await delete_wechat_task(current_user.user.user_id)

@changerController.post("/register")
async def register_api(
    data: dict,
    query_db: AsyncSession = Depends(get_db)
):
    """
    用户注册接口
    
    :param request: 请求对象
    :param data: 用户注册信息字典
    :param query_db: 数据库会话
    :return: 注册结果
    """
    return await register_user(data, query_db)

@changerController.post("/login")
async def login_api(
    request: Request,
    data: dict,
    query_db: AsyncSession = Depends(get_db)
):
    """
    邮箱密码登录接口
    
    :param request: 请求对象
    :param data: 登录信息字典
    :param query_db: 数据库会话
    :return: 登录结果
    """
    return await login(request, data, query_db)

@changerController.get("/userinfo")
async def get_user_info_api(
    current_user: CurrentUserModel = Depends(LoginService.get_current_user),
    query_db: AsyncSession = Depends(get_db)
):
    """
    获取用户详情接口
    
    :param current_user: 当前用户信息
    :param query_db: 数据库会话
    :return: 用户详情
    """
    return await UserService.get_user_info(current_user.user.user_id, query_db)

@changerController.post("/userinfo")
async def update_user_info_api(
    data: dict,
    current_user: CurrentUserModel = Depends(LoginService.get_current_user),
    query_db: AsyncSession = Depends(get_db)
):
    """
    更新用户详情接口
    
    :param current_user: 当前用户信息
    :param query_db: 数据库会话
    :return: 用户详情
    """
    return await UserService.update_user_info(current_user.user.user_id, data, query_db)


@changerController.get("/get-wechat-task")
async def get_task_api(
    current_user: CurrentUserModel = Depends(LoginService.get_current_user),
):
    """
    获取微信步数任务详情
    
    Args:
        count: 获取执行时间的次数，默认为5次
    """
    user_id = current_user.user.user_id
    return await get_task_info(user_id)

@changerController.get("/get-changer-notices")
async def get_changer_notices_api(
    query_db: AsyncSession = Depends(get_db)
):
    """
    获取指定部门的公告详情
    """
    return await UserService.get_changer_notices_api(query_db)

