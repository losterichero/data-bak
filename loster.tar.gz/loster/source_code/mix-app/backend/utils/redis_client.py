from redis import asyncio as aioredis

redis_instance = None  # 模块级的全局变量
def set_redis_instance(redis:aioredis.Redis):

    """
    global 关键字让你在函数内部 修改模块级变量。
    如果没有 global，Python 会认为你是在函数内部创建一个新的局部变量，导致你修改的只是局部变量而不是模块级变量。
    使用 global 后，你可以在函数内修改外部（模块级）的变量。
    """
    global redis_instance
    redis_instance = redis  # 把 redis 实例保存在模块作用域中

def get_redis() -> aioredis.Redis:
    return redis_instance