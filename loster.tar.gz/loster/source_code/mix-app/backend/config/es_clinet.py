from elasticsearch import Elasticsearch
from typing import Optional, Dict, Any

from dotenv import load_dotenv

from config.env import EsConfig

# 加载 .env 配置
load_dotenv()


class ElasticsearchClient:
    def __init__(self):
        # self.host = EsConfig.es_host
        # self.port = EsConfig.es_port
        self.host = "192.168.126.132"
        self.port = "9200"
        self.user = EsConfig.es_user
        self.password = EsConfig.es_password

        # 创建 Elasticsearch 客户端实例
        self.client = self._create_client()

    def _create_client(self) -> Elasticsearch:
        """初始化并返回 Elasticsearch 客户端实例"""
        if self.user and self.password:
            es = Elasticsearch(
                [f"http://{self.host}:{self.port}"],
                http_auth=(self.user, self.password)
            )
        else:
            es = Elasticsearch([f"http://{self.host}:{self.port}"])
        return es

    def search(self, index: str, body: Dict[str, Any], size: int = 10) -> Optional[Dict[str, Any]]:
        """执行查询操作"""
        try:
            response = self.client.search(index=index, body=body, size=size)
            print(f"查询结果{response}")
            return response
            return response["hits"]["hits"]
        except Exception as e:
            print(f"Error during search: {e}")
            return None

    def index_document(self, index: str, document: Dict[str, Any], doc_id: Optional[str] = None) -> bool:
        """索引文档"""
        try:
            if doc_id:
                self.client.index(index=index, id=doc_id, body=document)
            else:
                self.client.index(index=index, body=document)
            return True
        except Exception as e:
            print(f"Error during indexing: {e}")
            return False

    def delete_document(self, index: str, doc_id: str) -> bool:
        """删除文档"""
        try:
            self.client.delete(index=index, id=doc_id)
            return True
        except Exception as e:
            print(f"Error during document deletion: {e}")
            return False

    def check_connection(self) -> bool:
        """检查与 Elasticsearch 的连接是否正常"""
        try:
            return self.client.ping()
        except Exception:
            return False
