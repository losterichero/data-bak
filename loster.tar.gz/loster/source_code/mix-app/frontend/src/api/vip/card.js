import request from '@/utils/request'

const api_prefix = '/vip'

// 查询vip-card列表
export function listCard(query) {
  return request({
    url: '/system/card/list',
    method: 'get',
    params: query
  })
}

// 查询vip-card详细
export function getCard(id) {
  return request({
    url: '/system/card/' + id,
    method: 'get'
  })
}

// 新增vip-card
export function addCard(data) {
  return request({
    url: '/system/card',
    method: 'post',
    data: data
  })
}

// 修改vip-card
export function updateCard(data) {
  return request({
    url: '/system/card',
    method: 'put',
    data: data
  })
}

// 删除vip-card
export function delCard(id) {
  return request({
    url: '/system/card/' + id,
    method: 'delete'
  })
}




// 生成卡密
export function generateCardsApi(data) {
  return request({
    url: `${api_prefix}/generate-cards`,
    method: 'post',
    data
  })
}

// 兑换卡密
export function exchangeCardApi(data) {
  return request({
    url: `${api_prefix}/exchange-card`,
    method: 'post',
    data
  })
}

// 获取卡密列表
export function getCardListApi(params) {
  return request({
    url: `${api_prefix}/card-list`,
    method: 'get',
    params
  })
}

// 批量删除卡密
export function batchDeleteCardsApi(cardIds) {
  return request({
    url: `${api_prefix}/batch-delete-cards`,
    method: 'delete',
    data: {
      cardIds
    }
  })
}